FUNKESOUND — HANDOVER PACKAGE
=============================

The Cowork session that produced this lost its connection to the repo while one
commit ahead of origin/main. Everything unpushed is in here.

Last pushed commit on origin/main:  ceb087b


WHAT TO DO
----------

1. Put HANDOVER.md in the repo root and commit it, or just open it — it is the
   full brief for the next session. Everything else below is also explained in
   there.

2. Restore the two unpushed commits. Either method works; the patches were
   tested against a clean checkout of ceb087b and applied cleanly.

   Option A — patches:

     git checkout main && git pull
     git am --3way 0001-Publish-day-9-TV-Stand-vs-Wall-Mount-Which-Is-Better.patch
     git am --3way 0002-Add-blog-QC-tooling-and-the-session-handover.patch

   Option B — git bundle:

     git checkout main && git pull
     git pull /path/to/funkesound-day9.bundle main

3. Verify, then push:

     CF_PAGES_BRANCH=main ./build-cloudflare.sh
     node scripts/qc/blog-qc.mjs tv-stand-vs-wall-mount     # expect 18/18
     git push origin main

4. Wait about two minutes, then confirm:

     curl -s -o /dev/null -w '%{http_code}\n' https://funkesound.com/tv-stand-vs-wall-mount


IF THE PATCHES WILL NOT APPLY
-----------------------------

  day9-entry.ts   Paste as the FIRST element of BLOG_POSTS in
                  artifacts/funkesound/src/data/blog.ts, then set day 9 to
                  status: 'published' in blog-schedule.ts.

  media/          The two images. They go in
                  artifacts/funkesound/public/media/.

  The QC scripts are inside patch 0002 only. They are useful but not required
  to publish — if you lose them, HANDOVER.md describes what they check.


WHAT IS IN THE COMMITS
----------------------

  916feef  Day 9 blog post "TV Stand vs Wall Mount: Which Is Better?"
           1,389 words, written and fully QC'd, never pushed.
           2 files changed in src/data + 2 new images.

  86c4f52  scripts/qc/cfserve.mjs   Cloudflare Pages emulator
           scripts/qc/blog-qc.mjs   18 pre-publish checks against the build
           HANDOVER.md              this package's main document


FIRST THING TO ASK CLAUDE CODE
------------------------------

  "Read HANDOVER.md, apply the two patches in this folder, build, run the QC
   script on tv-stand-vs-wall-mount, and push. Then tell me what the known
   issues section says still needs fixing."
